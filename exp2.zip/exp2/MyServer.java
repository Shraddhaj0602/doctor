import java.rmi.registry.*;

public class MyServer {
    public static void main(String[] args) {
        try {
            // Start (or get) the registry on port 3000
            Registry registry = LocateRegistry.createRegistry(3000);

            // Create remote object
            Adder stub = new AdderRemote();

            // Bind using the Registry API directly
            registry.rebind("Shraddha", stub);

            System.out.println("✅ Server is ready and object bound as 'Shraddha'");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
