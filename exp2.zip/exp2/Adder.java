//code
import java.rmi.*;

public interface Adder extends Remote {
    public int add(int x, int y, int clientPort) throws RemoteException;
}
